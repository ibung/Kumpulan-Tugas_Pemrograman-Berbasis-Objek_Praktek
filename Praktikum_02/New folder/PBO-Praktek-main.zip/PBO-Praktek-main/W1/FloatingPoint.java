public class FloatingPoint {
    public static void main(String[] args) {
        double x = 92.98;
        int nx = (int) Math.round(x);
        System.out.println(nx);
    }
}
// Komentar: Math.round mengembalikan long, jadi perlu cast ke int.